Portoso_index = function(Xj=NULL){
  nj = table(Xj)
  S = length(nj)
  fi = nj/sum(nj)
  W = sum(fi*((2*(1:S)-S-1)/(S-1)))
  return(W)
}
