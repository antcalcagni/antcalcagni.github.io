SNA2324 - Summer 2024
Master in Data Science per il Welfare, University of Salento


=============================
R libraries to be installed
=============================
igraph
sna
ergm
btergm
lattice
sand
network


======================================================
igraph: Creating a graph from an external data frame
======================================================
Suppose we have two files structured as follows:

- d1 with variables id, var1, var2
- d2 with variables id1, id2, var3

where var1,..,var3 are variables of any type.

The keypoint here is that id contains distinct elements of interested 
(e.g., nodes of a network) with a collection of associated variables 
(in this case two only variables). Thus, the dataset d1 contains information 
about the units we need to analyse. On the contrary, the dataset d2 contains 
the pairwise connections (e.g., edges of a network) bewteen each unit labeled 
by id. Therefore, id1 and id2 contains duplicated  elements originally listed 
in d1:id. In this situation, a graph can be constructed by simply running the 
syntax

    graph = igraph::graph_from_data_frame(vertices=d1, d=d2, directed=TRUE/FALSE) 

with the result that nodes will be created using d1:id whereas edges 
using d2:{id1,id2}. This constitutes another way to create a graph from external 
files.
    

======================================
Datasets for exercises in labs/data/
======================================

#1 Movies
    MV_actors.csv   contains actors and some information about them (eg, gender)
    MV_movies.csv   contains two main actors (indexed from the previous dataset) 
                    for a list of movies

#2 Doctor House MD
    H_characters.txt    contains characters and associated attributes 
                        (eg, role in the fiction)
    H_relations.txt     contains for each pair of characters 
                        (indexed from the previous dataset) 
                        the type of relationship (eg, friend, colleague)
    H_teams.txt         contains further information about teams and their members
    
#3 Flights
    flights.csv         contains data about flights registered on 2015, 1st of February
    flights_info.txt    contains information about the variables the dataset contains
    
# Many other datasets can be retrieved from the public repository: 
  https://snap.stanford.edu/data/#citnets





    
